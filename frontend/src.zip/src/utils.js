// export const API_URL = 'https://mbuig2i6bdtonzsxfxbuohmvxq0esskf.lambda-url.ap-southeast-2.on.aws/api'
export const API_URL = 'http://localhost:8000/api'
