npm install package.json
npm start
